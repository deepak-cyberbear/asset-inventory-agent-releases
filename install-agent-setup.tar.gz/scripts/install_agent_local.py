#!/usr/bin/env python3
"""Install or update the latest public agent on this Ubuntu host."""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import socket
import sys
import tempfile
from pathlib import Path

try:
    from .install_agent_remote import (
        REMOTE_CONFIG,
        DEFAULT_API_URL,
        InstallError,
        download_release_agent,
        prompt_api_url,
        render_agent_config,
        run,
        stage_files,
    )
except ImportError:  # Direct execution from the extracted release package.
    from install_agent_remote import (
        REMOTE_CONFIG,
        DEFAULT_API_URL,
        InstallError,
        download_release_agent,
        prompt_api_url,
        render_agent_config,
        run,
        stage_files,
    )


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Download and install the latest Ubuntu agent release on this host."
    )
    parser.add_argument(
        "--api-url",
        default=os.environ.get("AGENT_API_URL")
        or os.environ.get("API_URL")
        or DEFAULT_API_URL,
        help="backend API base URL (defaults to the Azure pilot)",
    )
    parser.add_argument(
        "--device-id",
        default=os.environ.get("DEVICE_ID") or None,
        help="stable asset ID (defaults to this host's short hostname)",
    )
    parser.add_argument(
        "--reconfigure",
        action="store_true",
        default=os.environ.get("RECONFIGURE", "0").lower() in {"1", "true", "yes"},
        help="replace the saved API URL and device ID",
    )
    return parser.parse_args(argv)


def ensure_supported_host() -> None:
    try:
        os_release = Path("/etc/os-release").read_text(encoding="utf-8")
    except OSError as exc:
        raise InstallError(
            "Could not identify this operating system from /etc/os-release"
        ) from exc
    os_id = next(
        (line.partition("=")[2].strip().strip('"').strip("'") for line in os_release.splitlines()
         if line.startswith("ID=")),
        "",
    )
    if os_id != "ubuntu":
        raise InstallError("This installer supports Ubuntu only")
    if shutil.which("systemctl") is None or not Path("/run/systemd/system").exists():
        raise InstallError("systemd is required to install the agent service")


def install_staged_files(staging_dir: Path, *, install_config: bool) -> None:
    config_path = Path(REMOTE_CONFIG)
    if not install_config and not config_path.is_file():
        raise InstallError(
            "The existing agent configuration is missing; rerun with --reconfigure to create it"
        )

    run(["install", "-d", "-o", "root", "-g", "root", "-m", "0750", str(config_path.parent)])
    run(["install", "-d", "-o", "root", "-g", "root", "-m", "0755", "/usr/local/bin"])
    run(
        [
            "install",
            "-o",
            "root",
            "-g",
            "root",
            "-m",
            "0755",
            str(staging_dir / "vulnerability-agent"),
            "/usr/local/bin/vulnerability-agent",
        ]
    )
    run(["install", "-d", "-o", "root", "-g", "root", "-m", "0755", "/etc/systemd/system"])
    run(
        [
            "install",
            "-o",
            "root",
            "-g",
            "root",
            "-m",
            "0644",
            str(staging_dir / "vulnerability-agent.service"),
            str(staging_dir / "vulnerability-agent.timer"),
            str(staging_dir / "vulnerability-agent.path"),
            "/etc/systemd/system/",
        ]
    )
    if install_config:
        run(
            [
                "install",
                "-o",
                "root",
                "-g",
                "root",
                "-m",
                "0600",
                str(staging_dir / "agent.env"),
                str(config_path),
            ]
        )
    else:
        remove_legacy_upload_token(config_path)
    run(["systemctl", "daemon-reload"])
    run(["systemctl", "enable", "--now", "vulnerability-agent.timer", "vulnerability-agent.path"])
    run(["systemctl", "start", "vulnerability-agent.service"])
    run(
        [
            "systemctl",
            "--no-pager",
            "show",
            "-p",
            "Result",
            "-p",
            "ExecMainStatus",
            "vulnerability-agent.service",
        ]
    )
    run(["journalctl", "-u", "vulnerability-agent.service", "-n", "20", "--no-pager"])


def remove_legacy_upload_token(config_path: Path) -> None:
    """Remove the retired shared token from an existing systemd config."""
    contents = config_path.read_text(encoding="utf-8")
    lines = contents.splitlines(keepends=True)
    cleaned = [line for line in lines if not line.startswith("AGENT_UPLOAD_TOKEN=")]
    if cleaned != lines:
        config_path.write_text("".join(cleaned), encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if os.geteuid() != 0:
        raise InstallError("Run the installer as root, for example with sudo")
    ensure_supported_host()

    config_path = Path(REMOTE_CONFIG)
    if config_path.exists() and not config_path.is_file():
        raise InstallError(f"Agent config path exists but is not a file: {config_path}")
    config_exists = config_path.is_file()
    install_config = not config_exists or args.reconfigure
    if config_exists and not args.reconfigure:
        print("Existing agent config found; keeping its URL and device ID.")
        print("Pass --reconfigure to replace that configuration.")
        config = None
    else:
        api_url = prompt_api_url(args.api_url)
        if api_url.startswith("http://"):
            print(
                "Warning: HTTP does not encrypt inventory data; use HTTPS except on a "
                "trusted test network.",
                file=sys.stderr,
            )
        device_id = args.device_id or socket.gethostname().split(".", maxsplit=1)[0]
        config = render_agent_config(api_url, device_id)
        print(f"Configuring stable device ID: {device_id}")

    with tempfile.TemporaryDirectory(prefix="vulnerability-agent-release-") as release_dir:
        version, binary = download_release_agent(platform.machine().lower(), Path(release_dir))
        print(f"Installing public release {version} ({binary.name})...")
        staged = stage_files(binary, config)
        try:
            install_staged_files(Path(staged.name), install_config=install_config)
        finally:
            staged.cleanup()
    print("Agent installation completed.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except InstallError as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
